// Importing necessary Firebase functions
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { getFirestore, doc, getDoc, collection, getDocs } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC17BbuCs63DFzBdxnFFeO-Ejv1WECS7-E",
    authDomain: "book-pickup-kiosk01.firebaseapp.com",
    projectId: "book-pickup-kiosk01",
    storageBucket: "book-pickup-kiosk01.firebasestorage.app",
    messagingSenderId: "77991134959",
    appId: "1:77991134959:web:28dde2b643a22bed6abd1a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to fetch locker details and display the popup for "in-use" lockers
async function displayLockerContents(lockerNumber) {
    try {
        const lockerDoc = await doc(db, 'transactions', lockerNumber); // Get the locker document
        const lockerSnapshot = await getDoc(lockerDoc);

        if (lockerSnapshot.exists()) {
            const lockerData = lockerSnapshot.data();
            if (lockerData.status === "in-use") {
                const { bookDetails, recipientEmail, recipientName, transactionNumberField } = lockerData;

                // Generate and display the popup
                alert(
                    `Locker Contents:\n` +
                    `Book Details: ${bookDetails || 'N/A'}\n` +
                    `Recipient Email: ${recipientEmail || 'N/A'}\n` +
                    `Recipient Name: ${recipientName || 'N/A'}\n` +
                    `Transaction Number: ${transactionNumberField || 'N/A'}`
                );
            }
        } else {
            console.error(`Locker ${lockerNumber} does not exist in the database.`);
        }
    } catch (error) {
        console.error(`Error fetching locker data: ${error.message}`);
    }
}

// Function to fetch locker statuses and display the popup for "in-use" lockers
async function fetchLockerStatus() {
    const lockerList = document.getElementById('lockerList');
    if (!lockerList) {
        console.error("Locker list container is missing in the HTML.");
        return;
    }

    lockerList.innerHTML = ''; // Clear the list before adding new data

    try {
        // Fetch all documents in the 'lockers' collection
        const querySnapshot = await getDocs(collection(db, "lockers"));

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const status = data.status || 'available'; // Default to 'available' if no status is found
            const lockerNumber = data.lockerNumber; // Ensure you use lockerNumber, not 'number'

            // Create a list item for each locker
            const listItem = document.createElement('li');
            listItem.classList.add('locker'); // Add the 'locker' class for targeting in JS
            listItem.setAttribute('data-locker-number', lockerNumber); // Store locker number in data attribute
            listItem.innerHTML = `
                <span style="font-weight: bold;">Locker ${lockerNumber}:</span>
                <span class="status-dot" style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background-color: ${status === 'available' ? 'green' : 'red'}; margin-left: 10px;"></span>
                <span style="margin-left: 5px;">${status}</span>
            `;
            lockerList.appendChild(listItem);

            // Add hover effect for lockers with "in-use" status
            if (status === 'in-use') {
                listItem.classList.add('hover-in-use');
                
                // Add hover event listener to show popup with locker contents
                listItem.addEventListener('mouseover', async () => {
                    const lockerNumber = listItem.getAttribute('data-locker-number');
                    await displayLockerContents(lockerNumber);
                });

                // Add click event listener to show locker contents when clicked
                listItem.addEventListener('click', () => {
                    const lockerNumber = listItem.getAttribute('data-locker-number');
                    displayLockerContents(lockerNumber);
                });
            }
        });
    } catch (error) {
        console.error("Error fetching locker data:", error);
    }
}

// Function to display locker contents in a popup
async function displayLockerContents(lockerNumber) {
    try {
        const lockerDoc = await doc(db, 'transactions', lockerNumber); // Get the locker document
        const lockerSnapshot = await getDoc(lockerDoc);

        if (lockerSnapshot.exists()) {
            const lockerData = lockerSnapshot.data();
            if (lockerData.status === "in-use") {
                const { bookDetails, recipientEmail, recipientName, transactionNumberField } = lockerData;

                // Generate and display the popup
                alert(
                    `Locker Contents:\n` +
                    `Book Details: ${bookDetails || 'N/A'}\n` +
                    `Recipient Email: ${recipientEmail || 'N/A'}\n` +
                    `Recipient Name: ${recipientName || 'N/A'}\n` +
                    `Transaction Number: ${transactionNumberField || 'N/A'}`
                );
            }
        } else {
            console.error(`Locker ${lockerNumber} does not exist in the database.`);
        }
    } catch (error) {
        console.error(`Error fetching locker data: ${error.message}`);
    }
}

// Call the function to fetch locker statuses when page loads
window.addEventListener('DOMContentLoaded', fetchLockerStatus);

// CSS class for hover effect (add this to your CSS file or in a <style> tag)
document.head.insertAdjacentHTML('beforeend', `
    <style>
        .locker.hover-in-use:hover {
            background-color: #f0f0f0; /* Change this to any color/effect you prefer */
            cursor: pointer;
        }
    </style>
`);

