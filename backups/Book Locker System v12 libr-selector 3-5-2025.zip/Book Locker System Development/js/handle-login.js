type="module"
    import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
    import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-storage.js";
    import { getFirestore, collection, getDocs, doc, setDoc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
    import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js";

    const firebaseConfig = {
        apiKey: "AIzaSyC17BbuCs63DFzBdxnFFeO-Ejv1WECS7-E",
        authDomain: "book-pickup-kiosk01.firebaseapp.com",
        projectId: "book-pickup-kiosk01",
        storageBucket: "book-pickup-kiosk01.firebasestorage.app",
        messagingSenderId: "77991134959",
        appId: "1:77991134959:web:28dde2b643a22bed6abd1a"
    };

    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);
    const storage = getStorage(app);
    const auth = getAuth(app); // Initialize Firebase Authentication
// Handle login
// Function to show the login form modal
function showLoginModal() {
const loginModal = document.getElementById('login-form');
if (loginModal) {
loginModal.style.display = 'block'; // Show the modal
}
}

// Function to hide the login form modal
function hideLoginModal() {
const loginModal = document.getElementById('login-form');
if (loginModal) {
loginModal.style.display = 'none'; // Hide the modal
}
}

// Handling form submission and login
document.getElementById('login-form-inner').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');
  
    try {
      // Attempt to sign in with Firebase
      await signInWithEmailAndPassword(auth, email, password);
      
      // Hide the login modal and show content
      hideLoginModal();
      document.getElementById('content').style.display = 'block';
      
      // Automatically reload the page after successful login
      setTimeout(() => location.reload(), 500); // Short delay for smooth transition
    } catch (error) {
      // Handle errors
      switch (error.code) {
        case 'auth/user-not-found':
          errorMessage.textContent = 'No user found with this email.';
          break;
        case 'auth/wrong-password':
          errorMessage.textContent = 'Incorrect password.';
          break;
        case 'auth/invalid-email':
          errorMessage.textContent = 'Invalid email format.';
          break;
        default:
          errorMessage.textContent = 'Login failed. Please try again.';
      }
    }
  });
  

window.onload = function () {
onAuthStateChanged(auth, (user) => {
if (user) {
document.getElementById('content').style.display = 'block';
} else {
showLoginModal();
}
});
};

// Handle logout
document.getElementById('logout-button').addEventListener('click', async () => {
try {
await signOut(auth);
document.getElementById('content').style.display = 'none';
showLoginModal();
} catch (error) {
console.error("Error logging out:", error.message);
}
});

// Streamlined login logic, ensuring only login and logout functionalities remain
onAuthStateChanged(auth, (user) => {
if (user) {
document.getElementById('login-form').style.display = 'none';
document.getElementById('content').style.display = 'block';
} else {
document.getElementById('login-form').style.display = 'block';
document.getElementById('content').style.display = 'none';
}
});

// Function to log in a user
function logIn(email, password) {
auth.signInWithEmailAndPassword(email, password)
.then((userCredential) => {
const user = userCredential.user;
console.log("User logged in:", user);
})
.catch((error) => {
console.error("Error logging in:", error.message);
});
}

// Function to log out the user
function logOut() {
auth.signOut()
.then(() => {
console.log("User logged out");
})
.catch((error) => {
console.error("Error logging out:", error.message);
});
}
