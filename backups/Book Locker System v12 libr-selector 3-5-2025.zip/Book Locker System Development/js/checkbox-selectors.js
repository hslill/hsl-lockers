// Example of dynamically adding rows with checkboxes and unique data-doc-id attributes
const results = [
];

// Dynamically populate the table with checkboxes and data
const resultsBody = document.getElementById('results-body');
results.forEach(result => {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td><input type="checkbox" class="record-checkbox" name="selectRecord" data-doc-id="${result.id}"></td>
        <td>${result.lockerNumber}</td>
        <td>${result.transactionNumber}</td>
        <td>${result.dateReceived}</td>
        <td>${result.datePickedUp}</td>
        <td>${result.dateCanceled}</td>
        <td>${result.bookDetails}</td>
        <td>${result.recipientEmail}</td>
        <td>${result.recipient}</td>
        <td>${result.lockerStatus}</td>
        <td><button class="cancel-btn" data-doc-id="${result.id}">Cancel</button></td>
    `;
    resultsBody.appendChild(row);
});

// Handle checkbox changes
const handleCheckboxChange = (event) => {
    const checkbox = event.target;
    const docId = checkbox.getAttribute('data-doc-id');
    if (checkbox.checked) {
        console.log(`Checkbox for document ID ${docId} is checked.`);
    } else {
        console.log(`Checkbox for document ID ${docId} is unchecked.`);
    }
};

// Attach to individual checkboxes
const checkboxes = document.querySelectorAll('input[type="checkbox"]');
checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', handleCheckboxChange);
});

// Handle "Select All" checkbox
document.getElementById('select-all').addEventListener('change', (event) => {
    const isChecked = event.target.checked;
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:not(#select-all)');
    checkboxes.forEach(checkbox => {
        checkbox.checked = isChecked;
        const docId = checkbox.getAttribute('data-doc-id');
        if (isChecked) {
            console.log(`Checkbox for document ID ${docId} is checked.`);
        } else {
            console.log(`Checkbox for document ID ${docId} is unchecked.`);
        }
    });

    // Now check if any checkboxes are selected
    let selectedCount = 0;
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            selectedCount++;
        }
    });

    if (selectedCount === 0) {
        alert("No records selected.");
    } else {
        console.log(`${selectedCount} records selected.`);
    }
});

// Get selected records
function getSelectedRecords() {
    const selectedCheckboxes = document.querySelectorAll('input[name="selectRecord"]:checked');
    const selectedRecords = [];

    selectedCheckboxes.forEach(checkbox => {
        const recordId = checkbox.getAttribute('data-doc-id');
        selectedRecords.push(recordId);
    });

    return selectedRecords;
}

// Export to CSV based on selected records
document.getElementById('export-csv').addEventListener('click', function () {
    const selectedRecords = getSelectedRecords();
    if (selectedRecords.length === 0) {
        alert("No records selected.");
        return;
    }

    const table = document.getElementById("results-table");
    const headers = table.querySelectorAll("thead th");
    const rows = table.querySelectorAll("tbody tr");

    const headerData = [];
    headers.forEach(header => {
        headerData.push(header.textContent.trim());
    });

    const data = [headerData];

    rows.forEach(row => {
        const rowData = [];
        row.querySelectorAll("td").forEach(cell => {
            rowData.push(cell.textContent.trim());
        });

        // Check if the record is selected before adding to data
        const rowId = row.querySelector('input[name="selectRecord"]').getAttribute('data-doc-id'); // Get the recordId from the checkbox
        if (selectedRecords.includes(rowId)) {
            data.push(rowData);
        }
    });

    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'selected_records.csv';
    link.click();
});


// Export to PDF based on selected records
document.getElementById('export-pdf').addEventListener('click', function () {
    const selectedRecords = getSelectedRecords();
    if (selectedRecords.length === 0) {
        alert("No records selected.");
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'mm', 'letter');
    const table = document.getElementById("results-table");
    const rows = table.querySelectorAll("tbody tr");

    let y = 20;
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;

    const marginLeft = 10;
    const marginRight = 10;
    const marginTop = 20;
    const marginBottom = 20;

    doc.setFontSize(10);

    function wrapText(text, maxWidth) {
        return doc.splitTextToSize(text, maxWidth);
    }

    rows.forEach(row => {
        const rowData = {};
        row.querySelectorAll("td").forEach((cell, index) => {
            const header = [
                "Locker #",
                "Transaction Number",
                "Date Received",
                "Date Picked Up",
                "Date Canceled",
                "Book Details",
                "Recipient Email",
                "Recipient",
                "Locker Status"
            ][index];

            rowData[header] = cell.textContent.trim();
        });

        // Only include selected records
        if (selectedRecords.includes(rowData["Transaction Number"])) {
            Object.keys(rowData).forEach((header) => {
                const lineText = `${header} | ${rowData[header]}`;
                const wrappedLine = wrapText(lineText, pageWidth - marginLeft - marginRight);
                doc.text(wrappedLine, marginLeft, y);
                y += 10; // Move down for next line
            });
        }
    });

    doc.save('selected_records.pdf');
});

// Print selected records
document.getElementById("print-results").addEventListener("click", function () {
    const selectedRecords = getSelectedRecords();
    if (selectedRecords.length === 0) {
        alert("No records selected.");
        return;
    }

    const table = document.getElementById("results-table");
    const rows = table.querySelectorAll("tbody tr");

    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write('<html><head><title>Selected Transactions</title></head><body>');
    printWindow.document.write('<h1>Selected Transactions</h1>');
    printWindow.document.write('<table border="1"><thead><tr><th>Locker #</th><th>Transaction Number</th><th>Date Received</th><th>Date Picked Up</th><th>Date Canceled</th><th>Book Details</th><th>Recipient Email</th><th>Recipient</th><th>Locker Status</th></tr></thead><tbody>');

    rows.forEach(row => {
        const rowData = [];
        row.querySelectorAll("td").forEach(cell => {
            rowData.push(cell.textContent.trim());
        });

        // Check if the record is selected before adding to the printout
        if (selectedRecords.includes(rowData[1])) {
            printWindow.document.write('<tr>');
            rowData.forEach(cellData => {
                printWindow.document.write(`<td>${cellData}</td>`);
            });
            printWindow.document.write('</tr>');
        }
    });

    printWindow.document.write('</tbody></table>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
});
