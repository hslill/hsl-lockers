const sendConfirmationEmail = (transactionNumber, locker, combination) => {
    const emailParams = {
        recipient: 'david.desimone@nyulangone.org', // Add staff email(s) here
        subject: 'A Book was Picked Up',
        body: `
            Recipient: John Doe
            Book Info: Some Book Title
            Transaction Number: ${transactionNumber}
            Locker #: ${locker}
            Combination: ${combination}
        `
    };

    emailjs.send('desimd01', 'book-picked-up', emailParams)
        .then((response) => {
            console.log('Confirmation email sent:', response);
        }, (error) => {
            console.error('Error sending confirmation email:', error);
        });
};
