// Code for handling transaction validation or other logic can remain
const validateTransactionNumber = async (transactionNumber) => {
    try {
        const docRef = db.collection('book_picks').doc(transactionNumber);
        const doc = await docRef.get();

        if (!doc.exists) {
            alert('Transaction Number not found. Please enter a valid Transaction Number.');
            return false;
        }

        return true;
    } catch (error) {
        console.error('Error validating transaction number:', error);
        alert('There was an error validating the Transaction Number. Please try again.');
        return false;
    }
};

// Other logic as needed without declaring sendConfirmationEmail again
