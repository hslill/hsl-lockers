// Existing code for generating locker number and combination
let lockerNumber = assignLockerNumber();
let combination = generateCombination();

// Get all the necessary input fields
const recipientNameField = document.getElementById("recipientName");
const recipientEmailField = document.getElementById("recipientEmail");
const bookDetailsField = document.getElementById("bookDetails");
const transactionNumberField = document.getElementById("transactionNumberField");

// Function to generate a 4-digit combination
function generateCombination() {
    return Math.floor(1000 + Math.random() * 9000); // Generates a 4-digit number between 1000 and 9999
}

// Function to assign a locker number between 32 and 36
function assignLockerNumber() {
    const minLocker = 32;
    const maxLocker = 36;
    return Math.floor(Math.random() * (maxLocker - minLocker + 1)) + minLocker;
}

// Function to update email preview
function updateEmailPreview() {
    const recipientName = recipientNameField.value.trim();
    const recipientEmail = recipientEmailField.value.trim();
    const bookDetails = bookDetailsField.value.trim();
    const transactionNumber = transactionNumberField.value.trim();

    // Generate the barcode for the current transaction number
    const barcodeDataURL = generateBarcode(transactionNumber);

    // Generate locker number and combination
    const lockerNumber = assignLockerNumber();
    const combination = generateCombination();

    // Build the email content dynamically with HTML formatting
    let emailPreview = `
        <p>Hi ${recipientName || "[Recipient Name]"},</p>
        <p>You have material available for pickup at the <a href="https://hsl.med.nyu.edu/libraries/herman-robbins-medical-library-nyu-langone-orthopedic-hospital" target="_blank" rel="noopener">Herman Robbins Medical Library:</a></p>
        <p>${bookDetails || "[Book Details]"}</p>
        <p>Our pickup service operates 24/7, allowing you to retrieve it at any time. Please head to the kiosk located near the book lockers. You have two options to complete the process:</p>
        <img src="https://libapps.s3.amazonaws.com/accounts/129950/images/BookLockerPickup.JPG" width="187" height="240" alt="Book Locker Pickup Image">
        <ol>
            <li>Scan the barcode below using the handheld scanner provided at the kiosk.</li>
            <li>Alternatively, you can enter the Transaction Number displayed below the barcode and press ENTER or click the Submit button.</li>
        </ol>
        <p><strong>Transaction Number: </strong>${transactionNumber || "[Transaction Number]"}</p>
        <!-- Embed the barcode directly in the email preview -->
        <p><img src="${barcodeDataURL}" alt="Transaction Barcode" style="width: 200px; height: auto;"/></p>
        <p>The computer will then display the following details for your locker retrieval:</p>
        <ul>
            <li><strong>Locker Number:</strong> ${lockerNumber}</li>
            <li><strong>Combination:</strong> ${combination}</li>
        </ul>
        <p>If you encounter any issues or have questions, please feel free to contact the library.</p>
        <p>In case you no longer need the book(s), we kindly ask that you let us know as soon as possible. This will enable us to return the book(s) before the due date and prevent you from receiving any overdue notices.</p>
        <p>Best regards,</p>
        <p><strong>Document Delivery Services</strong><br>
        NYU Health Sciences Library at LOH<br>
        301 East 17th Street, Second Floor<br>
        New York, NY 10003<br>
        (212) 598-6275<br>
        <a href="mailto:dds@med.nyu.edu">dds@med.nyu.edu</a><br>
        <a href="https://nyulangone.org" target="_blank">nyulangone.org</a></p>
    `;

    // Insert the email content into the preview container
    const emailPreviewElement = document.getElementById("emailPreview");
    emailPreviewElement.innerHTML = emailPreview;

    // Add lockerNumber and combination to hidden fields for form submission
    document.getElementById("lockerNumberField").value = lockerNumber;
    document.getElementById("combinationField").value = combination;
}
// Listen for changes in the form fields and update the preview accordingly
recipientNameField.addEventListener("input", updateEmailPreview);
recipientEmailField.addEventListener("input", updateEmailPreview);
bookDetailsField.addEventListener("input", updateEmailPreview);
transactionNumberField.addEventListener("input", updateEmailPreview);
