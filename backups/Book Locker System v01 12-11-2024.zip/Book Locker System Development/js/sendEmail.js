// Initialize EmailJS
emailjs.init("WyYEU_8XtbqQYPJzD");  // Replace with your actual public key

// Form submission event listener
document.getElementById("notificationForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const btn = document.querySelector('button[type="submit"]');
    btn.textContent = "Sending...";

    // Get form field values
    const recipientName = document.getElementById("recipientName").value.trim();
    const recipientEmail = document.getElementById("recipientEmail").value.trim();
    const bookDetails = document.getElementById("bookDetails").value.trim();
    const transactionNumber = document.getElementById("transactionNumberField").value.trim();

    // Debugging log: Check if the email and other form values are captured correctly
    console.log("Recipient Name:", recipientName);
    console.log("Recipient Email:", recipientEmail);
    console.log("Book Details:", bookDetails);
    console.log("Transaction Number:", transactionNumber);

    if (!recipientEmail || !recipientName || !bookDetails || !transactionNumber) {
        alert("All fields must be filled out.");
        return;  // Prevent email sending if any field is missing
    }

    // Generate barcode URL
    const barcodeUrl = getBarcodeUrl(transactionNumber);
    console.log("Generated Barcode URL:", barcodeUrl);

    // Prepare the data to be sent to EmailJS
    const emailData = {
        recipientName: recipientName,  // Matches template placeholder
        recipientEmail: recipientEmail,
        bookDetails: bookDetails,      // Matches template placeholder
        transactionNumberField: transactionNumber,  // Matches template placeholder
        barcode_url: barcodeUrl
    };

    console.log("Data being sent to EmailJS:", emailData);

    // Send the email
    emailjs.send("desimd01", "book_pickup", emailData)
        .then((response) => {
            console.log('Email sent successfully!', response);
            alert('Email sent successfully!');
            btn.textContent = "Sent!";
        })
        .catch((error) => {
            console.error('Failed to send email:', error);
            alert('Failed to send email!');
            btn.textContent = "Send Notification";  // Reset the button text
        });
});
